package org.pd.streaming.window.example;

import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessAllWindowFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.windowing.assigners.GlobalWindows;
import org.apache.flink.streaming.api.windowing.triggers.CountTrigger;
import org.apache.flink.streaming.api.windowing.triggers.PurgingTrigger;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.api.datastream.AllWindowedStream;

import org.apache.flink.api.common.functions.FlatMapFunction;

import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.api.java.tuple.Tuple;
import java.util.Arrays;

public class GlobalWindowExample {
	static final Logger logger = LoggerFactory.getLogger(GlobalWindowExample.class);

    public static void main(String[] arg) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        AllWindowedStream<Tuple2<String, Integer>, GlobalWindow> countsWithoutPurge;
        AllWindowedStream<Tuple2<String, Integer>, GlobalWindow> countsWithPurge;
 	
        DataStream<Tuple2<String, Integer>> keyedValues = env.socketTextStream("localhost", 9999)
                .flatMap(new Splitter())
                // Key by Index-0 element of a Tuple (word)
                .keyBy(0);

	countsWithoutPurge = 
		keyedValues
                .windowAll(GlobalWindows.create()).trigger(CountTrigger.of(2));

/*	

	countsWithPurge = 
		keyedValues
		.windowAll(GlobalWindows.create())
		.trigger(PurgingTrigger.of(CountTrigger.of(2)));
*/
	countsWithoutPurge.sum(1).print();

//	countsWithPurge.sum(1).print();

        env.execute("Global Window WordCount");
    }

    private static class Splitter implements FlatMapFunction<String, Tuple2<String, Integer>> {
        @Override
        public void flatMap(String sentence, Collector<Tuple2<String, Integer>> out) throws Exception {
            Arrays.stream(sentence.split(" ")).forEach(word -> out.collect(new Tuple2<String, Integer>(word, 1)));
        }
    }
}

